const init = {}

const appReducer = (state = init, action) => {
    return state
}
export default appReducer
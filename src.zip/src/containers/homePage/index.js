import React from 'react'
import './style.scss'
const HomePage = () => {
    return (
        <div className="homePageAreaa">
            <h1 className="display-1 text-center">React Boilarplate</h1>
        </div>
    )
}
export default HomePage